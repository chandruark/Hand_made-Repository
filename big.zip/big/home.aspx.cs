﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Data.Sql;
namespace big
{
    public partial class home : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=c:\users\loganathan\documents\visual studio 2013\Projects\big\big\App_Data\db.mdf;Integrated Security=True"); 

        protected void Page_Load(object sender, EventArgs e)
        {
            ImageButton3.ImageUrl = "~/img/1.jpg";

            con.Open();
            String select = "select name from home where id='1'";
            SqlCommand com = new SqlCommand(select, con);
            string name = com.ExecuteScalar().ToString();
            if (name != " ")
            {
                Label1.Text ="Welcome "+ name;
                ImageButton2.ImageUrl = "~/img/person.png";
            }

        }

        protected void Timer1_Tick(object sender, EventArgs e)
        {
            Random r = new Random();
            int num = r.Next(1,7);
            ImageButton3.ImageUrl = "~/img/"+num+".jpg";
        }

       

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("login.aspx");
        }

        protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
        {
           Response.Redirect("location.aspx");
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("cart.aspx");
        }

        protected void ImageButton9_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("groceries.aspx");
        }

        protected void ImageButton10_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("personal_care.aspx");

        }

        protected void ImageButton11_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("beverages.aspx");

        }

        protected void ImageButton8_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("fruits.aspx");
        }
    }
}