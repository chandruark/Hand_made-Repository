﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
namespace big
{
    public partial class insert_beverages : System.Web.UI.Page
    {
        int i = 1;
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Loganathan\Documents\Visual Studio 2013\Projects\big\big\App_Data\db.mdf;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string select = "select * from beverages";
            con.Open();
            SqlCommand com = new SqlCommand(select, con);
            com.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(com);
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            con.Close();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (FileUpload1.HasFile)
            {
                con.Open();

                FileUpload1.PostedFile.SaveAs(Server.MapPath(("~/beverages/") + FileUpload1.FileName));
                string str = "insert into beverages values(" + i + ",'" + "beverages/" + FileUpload1.FileName + "','" + TextBox2.Text + "'," + TextBox3.Text + ")";

                SqlCommand cmd = new SqlCommand(str, con);
                cmd.ExecuteNonQuery();

                //   Response.Redirect("login.aspx");


                string select = "select * from beverages";
                SqlCommand com = new SqlCommand(select, con);
                com.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(com);
                da.Fill(dt);
                GridView1.DataSource = dt;
                GridView1.DataBind();
                con.Close();


            }
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("home.aspx");
        }
    }
}