﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
namespace big
{
    public partial class location : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=c:\users\loganathan\documents\visual studio 2013\Projects\big\big\App_Data\db.mdf;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button1_Click(object sender, EventArgs e)
        {

            string fname=null, lname=null, email, add, pin;
            string phone;
            fname = TextBox1.Text;
            lname = TextBox2.Text;
            email = TextBox3.Text;
            pin = TextBox4.Text;
            add = TextBox5.Text;
            phone = TextBox6.Text;
            string name = String.Concat(fname," "+lname);
            Regex regex = new Regex("^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$");
            Match match = regex.Match(email);
            Boolean result = match.Success;

            try
            {
                if (fname == "" || lname == "")
                {
                    Label1.Text = "Complete all the box";
                }

                
                else if (result.Equals(false))
                {
                    Label9.Text = "Enter valid mail ID";
                }

                else if (phone.Length != 10)
                {
                    throw (new IndexOutOfRangeException());
                }
                else
                {
                    string str = "insert into address values('" + add + "','" + phone + "','" + email + "','" + name + "','" + pin + "')";
                    SqlCommand cmd = new SqlCommand(str, con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                   // Response.Redirect("login.aspx");
                }
            }


            catch (IndexOutOfRangeException)
            {
                Label13.Text = "Varify mobile number";

            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string select = "select * from address";

            con.Open();
            SqlCommand com = new SqlCommand(select, con);
            com.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(com);
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            con.Close();
       }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("home.aspx");
        }
    }
}