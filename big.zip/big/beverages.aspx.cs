﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
namespace big
{
    public partial class beverages : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Loganathan\Documents\Visual Studio 2013\Projects\big\big\App_Data\db.mdf;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            Random r = new Random();
            int num = r.Next(1, 7);
            ImageButton3.ImageUrl = "~/beverages/" + num + ".jpg";
            string select = "select * from beverages";
            con.Open();
            SqlCommand com = new SqlCommand(select, con);
            com.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(com);
            da.Fill(dt);
            DataList1.DataSource = dt;
            DataList1.DataBind();
            con.Close();
        }

        protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("home.aspx");
            //  string ins = "insert into cart values()";
        }
        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {

        }
        protected void Timer1_Tick(object sender, EventArgs e)
        {
            Random r = new Random();
            int num = r.Next(1, 5);
            ImageButton3.ImageUrl = "~/beverages/" + num + ".jpg";
        }

        protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("home.aspx");
        }

        protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
        {

            Response.Redirect("home.aspx");
        }
    }
}