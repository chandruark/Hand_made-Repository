﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Data.Sql;
namespace big
{
    public partial class login : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=c:\users\loganathan\documents\visual studio 2013\Projects\big\big\App_Data\db.mdf;Integrated Security=True"); 

        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            string emails = TextBox1.Text;
            string pass = TextBox2.Text;
            if(emails=="gss"&&pass=="gss")
            {
                Response.Redirect("admin.aspx");
            }
            con.Open();
            string work = "Select password from login where email='" + emails + "'";
            SqlCommand cmd = new SqlCommand(work, con);
            string pass1 = cmd.ExecuteScalar().ToString();
            if (pass == pass1)
            {
                String select1 = "select fname from login where email='" + emails + "'";
                SqlCommand com1 = new SqlCommand(select1, con);
                String name = com1.ExecuteScalar().ToString();

                String insert1 = "UPDATE home SET name='" + name + "' WHERE id=1";
                SqlDataAdapter d = new SqlDataAdapter(insert1, con);
                SqlCommand com2 = new SqlCommand(insert1, con);
                DataSet ds = new DataSet();
                d.Fill(ds);
                Response.Redirect("home.aspx");
            }
            else
            {
                Label5.Text = "Either email or password wrong";
            }
            con.Close();

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("signup.aspx");
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("home.aspx");
        }
    }
}