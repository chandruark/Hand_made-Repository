package com.example.chandruark.mybottom;

import android.app.Activity;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.support.v4.app.FragmentTransaction;
import android.os.Bundle;

import com.example.chandruark.mybottom.R;
import com.roughike.bottombar.BottomBar;
import com.roughike.bottombar.BottomBarBadge;
import com.roughike.bottombar.OnMenuTabClickListener;
import android.view.Menu;

public class MainActivity extends AppCompatActivity {

    BottomBar nBottomBar;
    //private Activity savedInstanceState;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        nBottomBar=BottomBar.attach(this,savedInstanceState);
        nBottomBar.setItemsFromMenu(R.menu.menu_main, new OnMenuTabClickListener() {
            @Override
            public void onMenuTabSelected(@IdRes int menuItemId)

            {
                if (menuItemId == R.id.Bottombaritemone) {
                    Cardsfragment f = new Cardsfragment();
                    getFragmentManager().beginTransaction().replace(R.id.frame, f).commit();
                } else if (menuItemId == R.id.Bottombaritemtwo) {
                    Favourfragment f = new Favourfragment();
                    getFragmentManager().beginTransaction().replace(R.id.frame, f).commit();
                } else if (menuItemId == R.id.Bottombaritemthree) {
                    peopleFragment f = new peopleFragment();
                    getFragmentManager().beginTransaction().replace(R.id.frame, f).commit();
                } else if (menuItemId == R.id.Bottombaritemfour) {
                    phonefragment f = new phonefragment();
                    getFragmentManager().beginTransaction().replace(R.id.frame, f).commit();
                } else if (menuItemId == R.id.Bottombaritemfive) {
                    snowfragement f = new snowfragement();
                    getFragmentManager().beginTransaction().replace(R.id.frame, f).commit();
                }
            }

            @Override
            public void onMenuTabReSelected(int menuItemId) {

            }


        });
        nBottomBar.mapColorForTab(0, "#ABB2B9");
        nBottomBar.mapColorForTab(1, "#F4D03F");
        nBottomBar.mapColorForTab(2,"#4A235A");
        nBottomBar.mapColorForTab(3,"#76D7C4");
        nBottomBar.mapColorForTab(4, "#17202A");


        BottomBarBadge unread;
        unread=nBottomBar.makeBadgeForTabAt(3,"#FF3000",13);
        unread.show();

        
    }
}

